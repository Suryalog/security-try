package com.example.Security.greetings;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class GreetingsController {
	
	@GetMapping("/print")
	public ResponseEntity<String> sayGoodBye(){
		return ResponseEntity.ok("Good Bye and see you");
	}

}
