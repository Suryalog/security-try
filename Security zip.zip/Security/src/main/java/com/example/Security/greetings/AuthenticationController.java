package com.example.Security.greetings;

import org.springframework.http.ResponseEntity;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.authorization.AuthenticatedAuthorizationManager;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.example.Security.Config.JwtUtils;
import com.example.Security.dao.AuthenticationRequest;

@RestController
public class AuthenticationController {

	private AuthenticationManager authenticationManager;
	
	private UserDetailsService userDetailsService;
	
	private JwtUtils jwtUtils;
	
	@PostMapping("/authenticate")
	public ResponseEntity<String> authenticate(@RequestBody AuthenticationRequest request){
	    authenticationManager.authenticate(
	    		new UsernamePasswordAuthenticationToken(request.getEmail(), request.getPassword()));
	
	    UserDetails user=userDetailsService.loadUserByUsername(request.getEmail());
	    if(user!=null) {
	       return ResponseEntity.ok(jwtUtils.generateToken(user));
	    }
	    return ResponseEntity.status(400).body("error occured");
	   
	}
	
	
	
}
